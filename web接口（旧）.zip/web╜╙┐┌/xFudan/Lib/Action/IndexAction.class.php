<?php
class IndexAction extends Action {
    public function index($uid1,$uid2){
    	echo md5(time());
    }
}